import React from 'react'
import { MdOutlineLibraryBooks } from 'react-icons/md'
import Question from './Question'

const Faq = () => {
  return (
    <section id='faq'>
      <div className='container faq'>
      <div className='u-title'>
          <MdOutlineLibraryBooks  color='orangered' size={30}/>
          <h2>FAQS</h2>
          <p className='u-text-small u-text-dark' >
          The Minority Leader is the Principal Spokesperson
              for the Minority Caucus in Parliament
          </p>
        </div>
        <div className='question'>
         <Question />
        </div>
      </div>
      
    </section>
  )
}

export default Faq