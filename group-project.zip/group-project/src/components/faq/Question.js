import React from 'react'
import './Question.css'
import {AiOutlinePlus, AiOutlineMinus} from 'react-icons/ai'

const Question = () => {
    return (
        <div className='container question'>
        <div className='question-title'>
            <h4>Who is the speaker now?</h4>
            <button className='question-icon'>
                btn
            </button>
        </div>
        <div className='question-answer'></div>
        <p className='u-text-small'>
            Lorem Ipsum is simply dummy text of the printing and 
            typesetting industry. Lorem Ipsum has been the industry's 
            standard dummy text ever since the 1500s, when an unknown printer took a galley of type
             and scrambled it to make a type specimen book.",
        </p>

        </div>
    )
}

export default Question