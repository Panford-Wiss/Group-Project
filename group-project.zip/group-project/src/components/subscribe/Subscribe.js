import React from 'react'
import './Subscribe.css'
import {TiSocialGooglePlus} from 'react-icons/ti'
import { FaFacebookF, FaTwitter, FaInstagram,FaYoutube } from 'react-icons/fa'


const Subscribe = () => {
  return (
   <section id = "subscribe">
     <div className='container subscribe'>
       <h2>Contact UGPH NOW!</h2>
       <form>
         <div className='form-control'>
           <div>
           <input type="text" placeholder = "Enter your FullName..."/>
             </div>
             <br/>
             <div>
           <input type="email" placeholder = "Enter your Email..."/>
             </div>
             <br/>
             <div>
           <input type="number" placeholder = "Enter your PhoneNumber...."/>
             </div>
             <br/>
             <textarea name='my_textarea' rows= "10" cols="25" spellCheck="true" placeholder='Type your Message Here...'/>
             <div className= 'button-1'>
             <button> Send Message</button>
             </div>
              

         </div>
       </form>
       <h2>Connect With UGPH Here </h2>
       <div className='social-icons'>
         <div className='social-icon'>
           <TiSocialGooglePlus/>
         </div>
         <div className='social-icon'>
           <FaFacebookF/>
         </div>
         <div className='social-icon'>
           <FaTwitter/>
         </div>
         <div className='social-icon'>
           <FaInstagram/>
         </div>
         <div className='social-icon'>
           <FaYoutube/>
         </div>
         
       </div>
     </div>
      
   </section>
  )
}

export default Subscribe